//create variables 
var monkey, monkey_running;
var backgrnd, bckgrndimg;
var ground, groundimg;
var FoodGroup, bananaimg, ObstacleGroup, obstacleimg;
var score = 0;



function preload() {
  //load the images of background here
  bckgrndimg = loadImage("jungle2.jpg")
  monkey_running = loadAnimation("Monkey_01.png", "Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", "Monkey_07.png", "Monkey_08.png", "Monkey_09.png", "Monkey_10.png")
  bananaimg = loadImage("Banana.png");
  obstacleimg = loadImage("stone.png");


}

function setup() {
  //craeted the canvas already
  createCanvas(800, 400);
  backgrnd = createSprite(0, 0, 800, 400)
  backgrnd.addImage(bckgrndimg);
  backgrnd.scale = 1.5;
  backgrnd.x = backgrnd.width / 2
  backgrnd.velocityX = -4;

  monkey = createSprite(100, 340, 10, 10);
  monkey.addAnimation("running", monkey_running);
  monkey.scale = 0.1;    




  //create the ground here,give the velocityX,make the ground invisible
  ground = createSprite(400, 350, 800, 10);
  ground.velocityX = -4
  ground.x = ground.width / 2;
  ground.visible = false;


  FoodGroup = new Group();
  ObstacleGroup = new Group();

}

function draw() {

  background(255);

  //if statement for the ground and backgrnd to reset as it goes out of the canvas from the left
  //eg 
  if (ground.x < 0) {
    ground.x = ground.width / 2;
  }
  if (backgrnd.x < 0) {
    backgrnd.x = backgrnd.width / 2;
  }

  //if statement when the food group is going the touch the player
  //destroy the foodgroup and increase the score
  if (FoodGroup.isTouching(monkey)) {
    FoodGroup.destroyEach();
    score = score + 2;
  }

  //when the score increases to 10, the scale of the monkey increases
  //do the same for 3 more cases(20,30,40)
  // i have done it for case 10

  switch (score) {
    case 10:
     monkey.scale = 0.12;
      break;
    case 20:
     monkey.scale = 0.14;
      break;

    case 30:
      monkey.scale = 0.16;
      break;

    case 40:
      monkey.scale = 0.18;
      break;
    case 50:
      monkey.scale = 0.2;
      break;


    default:
      break;
  }

  //make the monkey jump here using the space bar
  if(keyDown("space")){
    monkey.velocityY=-10
  }

monkey.velocityY=monkey.velocityY+0.8;


  //make the monkey collide with the ground
monkey.collide(ground);

  spawnFood();
  spawnObstacles();

  //change the scale of the monkey if it touches the obstacle
  if (ObstacleGroup.isTouching(monkey)) { 
monkey.scale=0.08;

  }

  drawSprites();

  //displaying of the score>>>already done
  stroke("white");
  textSize(20);
  fill("white");
  text("Score: " + score, 200, 50);
}

function spawnFood() {
  //write code here to spawn the food after every 80 frames
  if (frameCount % 80 === 0) {
 var banana=createSprite(600,240,10,10)
 banana.addImage(bananaimg);
    banana.y=random(120,200);
    banana.scale=0.05;
    banana.velocityX=-5
    banana.lifetime=300;
    FoodGroup.add(banana);

    //add each banana to the group

  }
}

function spawnObstacles() {
  //write code here to spawn the food after every 300 frames
  if (frameCount % 200 === 0) {    
var stone= createSprite(800,350,10,10);
    stone.addImage(obstacleimg);
    stone.velocityX=-6
    stone.scale=0.2
    stone.lifetime=300;
    ObstacleGroup.add(stone);
  

    

  }
}